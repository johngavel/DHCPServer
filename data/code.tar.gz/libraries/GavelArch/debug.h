#ifndef __GAVEL_DEBUG
#define __GAVEL_DEBUG

#include "serialport.h"

#define DEBUG(s) CONSOLE->println(TRACE, s)

#endif