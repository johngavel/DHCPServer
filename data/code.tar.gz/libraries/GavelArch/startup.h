#ifndef __GAVEL_STARTUP
#define __GAVEL_STARTUP

void setup0Start();
void setup1Start();
void setup0Complete();
void setup1Complete();

#endif