#ifndef __DHCP_WEBSERVER
#define __DHCP_WEBSERVER

void setupServerModule();

#endif